import React from 'react'

export const Header = () => {
    return(
        <div className="header">
            <h1>React With NodeJS</h1>
        </div>
    )
}